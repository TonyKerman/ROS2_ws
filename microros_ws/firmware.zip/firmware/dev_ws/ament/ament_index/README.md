See https://github.com/ament/ament_cmake/blob/master/ament_cmake_core/doc/resource_index.md for documentation on the ament resource index.

See https://github.com/ament/ament_cmake/tree/master/ament_cmake_core/cmake/index for the corresponding CMake implementation of the resource index.
