^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ament_vendor_package
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.5 (2023-06-22)
------------------
* Add ament_cmake_vendor_package package (`#467 <https://github.com/ament/ament_cmake/issues/467>`_)
